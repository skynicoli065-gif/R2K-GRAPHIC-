# R2K GRAPHIC Android starter project

This is an Android Studio project that packages the current R2K GRAPHIC HTML prototype inside an Android WebView. It enables JavaScript/local storage, supports selecting a file for an HTML upload control, and applies Android `FLAG_SECURE` to block screenshots and screen recording while the app is visible.

## Build
1. Install Android Studio on a computer.
2. Open this folder (`R2K_GRAPHIC_Android`) in Android Studio.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

## Important limitations
- This is a packaged prototype, not a production-ready commercial app.
- The current HTML prototype is bundled offline. It does not provide a live shared customer/admin database.
- Real payment receipt storage, manual admin approval, secure accounts, one-time server-enforced editing tokens, and hosting must be implemented on a trusted backend before accepting customer payments.
- `FLAG_SECURE` blocks ordinary Android screenshots/recordings, but cannot prevent photos taken with another device. Website browsers cannot reliably block screenshots.
- Do not put secret admin credentials or payment verification logic in the HTML/app. Keep those on the backend.
- Have a parent/guardian help with hosting, payment-account setup, and publishing.
